
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ChevronDown, ShieldCheck, Star, Gift } from 'lucide-react';

// --- HERO MOCKUP (CSS ONLY 3D COMPOSITION) ---
export const HeroMockup: React.FC = () => {
  return (
    <div className="relative w-full h-[400px] md:h-[600px] flex items-center justify-center perspective-[1000px]">
       {/* Back Layer - Tablet/Sheet (Green - Auto) */}
       <div className="absolute top-1/2 left-1/2 transform -translate-x-1/4 -translate-y-1/2 rotate-[15deg] w-48 h-64 md:w-64 md:h-80 bg-[#0a0a0a] border border-neon-green/50 rounded-xl shadow-[0_0_40px_rgba(34,197,94,0.15)] flex flex-col items-center justify-center p-4 z-0 hover:z-30 hover:rotate-0 transition-all duration-500 group hover:scale-110">
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-1 h-1 bg-stone-700 rounded-full"></div>
          <div className="w-full h-full border border-stone-800 rounded-lg flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
             <span className="text-3xl mb-2 group-hover:scale-125 transition-transform">⚡</span>
             <div className="text-neon-green font-heading font-bold text-lg text-center leading-none">SISTEMA<br/>AUTÓNOMO</div>
             <div className="mt-2 text-[8px] md:text-[10px] text-stone-400 text-center uppercase tracking-wider">Manual de Piloto</div>
          </div>
       </div>

       {/* Middle Layer - Book (Red - Cardio) */}
       <div className="absolute top-1/2 left-1/2 transform -translate-x-3/4 -translate-y-1/2 -rotate-[10deg] w-52 h-72 md:w-72 md:h-96 bg-[#0a0a0a] border-l-4 border-l-stone-800 border-y border-r border-stone-800 border-b-neon-red/50 rounded-r-lg shadow-[0_0_40px_rgba(239,68,68,0.15)] flex flex-col items-center justify-center p-4 z-10 hover:z-30 hover:rotate-0 transition-all duration-500 group hover:scale-110">
           <div className="absolute inset-0 bg-gradient-to-br from-transparent to-neon-red/5 pointer-events-none"></div>
           <div className="text-neon-red font-heading font-black text-2xl md:text-3xl text-center leading-none mb-2">CÓDIGO<br/>CARDIO</div>
           <div className="w-16 h-16 rounded-full border-2 border-neon-red/30 flex items-center justify-center group-hover:border-neon-red transition-colors">
              <span className="text-neon-red text-2xl">❤</span>
           </div>
           <p className="mt-4 text-stone-500 text-xs text-center max-w-[80%]">Hidráulica del cuerpo humano</p>
       </div>

       {/* Front Layer - Main Book (Purple - Neuro) */}
       <div className="relative w-64 h-[340px] md:w-80 md:h-[500px] bg-[#050505] border-l-8 border-stone-900 border-y border-r border-stone-800 border-r-neon-purple/30 rounded-r-xl shadow-[0_0_60px_rgba(168,85,247,0.25)] flex flex-col items-center justify-between p-6 z-20 transform hover:scale-105 transition-transform duration-500 group overflow-hidden">
           {/* Spine Shadow */}
           <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-stone-800 to-transparent z-30"></div>
           
           {/* Shine Effect */}
           <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-12 group-hover:left-[200%] transition-all duration-1000 ease-in-out"></div>

           <div className="w-full text-center relative z-10 mt-4">
              <h1 className="text-white font-heading font-black text-3xl md:text-5xl leading-[0.85] tracking-tighter drop-shadow-xl">
                  NEURO<br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-b from-neon-purple to-purple-900">ANATOMÍA</span>
              </h1>
              <div className="bg-yellow-400 text-black text-[10px] md:text-xs font-black px-3 py-1 inline-block mt-3 transform -rotate-2 shadow-lg">
                  EN 60 MINUTOS
              </div>
           </div>
           
           <div className="flex-1 w-full flex items-center justify-center my-2 relative">
               {/* Brain Visualization */}
               <div className="w-40 h-40 md:w-56 md:h-56 rounded-full bg-gradient-to-b from-neon-purple/10 to-transparent flex items-center justify-center relative">
                  <div className="absolute inset-0 border border-neon-purple/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
                  <div className="absolute inset-4 border border-neon-purple/10 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
                  <span className="text-6xl md:text-7xl filter drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]">🧠</span>
               </div>
           </div>

           <div className="w-full text-center relative z-10 mb-2">
               <p className="text-stone-600 text-[10px] md:text-xs uppercase tracking-[0.2em] font-bold">Colección Maestra</p>
               <div className="w-full h-px bg-stone-800 my-2"></div>
               <p className="text-stone-400 font-bold text-xs">Volumen 1</p>
           </div>
       </div>
    </div>
  )
}

// --- PRODUCT STACK CARD ---
interface ModuleCardProps {
    title: string;
    subtitle: string;
    description: string;
    image: string;
    color: 'purple' | 'green' | 'red';
    isBonus?: boolean;
    referencePrice?: string;
    payPrice?: string;
}

export const ModuleCard: React.FC<ModuleCardProps> = ({ title, subtitle, description, image, color, isBonus = false, referencePrice, payPrice }) => {
    const colorClasses = {
        purple: { border: 'border-neon-purple', text: 'text-neon-purple', shadow: 'shadow-neon-purple/20' },
        green: { border: 'border-neon-green', text: 'text-neon-green', shadow: 'shadow-neon-green/20' },
        red: { border: 'border-neon-red', text: 'text-neon-red', shadow: 'shadow-neon-red/20' },
    };

    const theme = colorClasses[color];

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className={`relative flex flex-col md:flex-row bg-page-card rounded-xl border ${isBonus ? 'border-2 border-dashed ' + theme.border : 'border border-stone-800'} overflow-hidden hover:${theme.shadow} hover:shadow-lg transition-all duration-300 group`}
        >
             {isBonus && (
                 <div className={`absolute top-0 right-0 ${color === 'green' ? 'bg-neon-green' : 'bg-neon-purple'} text-black text-xs font-black px-3 py-1 rounded-bl-lg z-10`}>
                     BONUS EXCLUSIVO
                 </div>
             )}
            
            <div className="md:w-1/3 relative overflow-hidden min-h-[200px] bg-stone-900 flex items-center justify-center">
                 <div className={`absolute inset-0 bg-gradient-to-t from-black to-transparent z-10 opacity-60`}></div>
                 {/* Fallback Icon if image fails or is placeholder */}
                 <div className="text-6xl opacity-50 grayscale group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:scale-110">
                    {color === 'purple' && '🧠'}
                    {color === 'green' && '⚡'}
                    {color === 'red' && '❤'}
                 </div>
            </div>
            
            <div className="md:w-2/3 p-6 flex flex-col justify-center">
                <div className="flex justify-between items-start w-full mb-2">
                     <h4 className={`text-sm font-bold tracking-widest uppercase ${theme.text}`}>{subtitle}</h4>
                     <div className="flex flex-col items-end">
                        {referencePrice && (
                            <div className="relative mb-1">
                                <span className="text-stone-500 font-bold text-xs md:text-sm">Valor: {referencePrice}</span>
                                {/* Graphic Strikethrough */}
                                <div className="absolute left-0 right-0 top-1/2 h-[2px] bg-neon-red transform -rotate-3 scale-110"></div>
                            </div>
                        )}
                        {payPrice && (
                            <span className={`font-black text-lg tracking-tight ${payPrice === 'GRATIS' ? 'text-neon-green text-2xl drop-shadow-[0_0_5px_rgba(34,197,94,0.5)]' : 'text-white'}`}>
                                {payPrice}
                            </span>
                        )}
                     </div>
                </div>
                <h3 className="font-heading text-2xl font-bold text-white mb-3 leading-tight pr-8 md:pr-0">{title}</h3>
                <p className="text-stone-400 text-sm leading-relaxed">{description}</p>
                
                <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-white/80">
                    <div className={`p-1 rounded-full ${theme.text} border border-current`}><Check size={10} strokeWidth={4} /></div>
                    <span>Disponible inmediatamente</span>
                </div>
            </div>
        </motion.div>
    );
};

// --- FAQ ACCORDION ---
export const FAQAccordion: React.FC<{ items: { q: string, a: string }[] }> = ({ items }) => {
    const [activeIndex, setActiveIndex] = useState<number | null>(null);

    return (
        <div className="space-y-4 max-w-3xl mx-auto">
            {items.map((item, idx) => (
                <div key={idx} className="bg-page-card border border-stone-800 rounded-lg overflow-hidden">
                    <button 
                        onClick={() => setActiveIndex(activeIndex === idx ? null : idx)}
                        className="w-full p-6 flex justify-between items-center text-left hover:bg-white/5 transition-colors"
                    >
                        <span className="font-heading font-semibold text-lg text-white">{item.q}</span>
                        <ChevronDown className={`text-stone-500 transition-transform duration-300 ${activeIndex === idx ? 'rotate-180' : ''}`} />
                    </button>
                    <AnimatePresence>
                        {activeIndex === idx && (
                            <motion.div 
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="bg-black/30"
                            >
                                <div className="p-6 pt-0 text-stone-400 leading-relaxed">
                                    {item.a}
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            ))}
        </div>
    );
};

// --- GUARANTEE SEAL 1 ---
export const GuaranteeSeal: React.FC = () => {
    return (
        <div className="flex flex-col md:flex-row items-center gap-6 bg-page-card border border-stone-800 p-8 rounded-2xl w-full relative overflow-hidden group hover:border-neon-green/30 transition-colors">
            {/* Background Glow */}
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-neon-green/5 blur-[80px] rounded-full pointer-events-none group-hover:bg-neon-green/10 transition-all"></div>
            
            <div className="flex-shrink-0">
                 <div className="w-20 h-20 rounded-full border-2 border-neon-green flex items-center justify-center bg-black shadow-[0_0_20px_rgba(34,197,94,0.2)]">
                    <ShieldCheck size={40} className="text-neon-green" />
                 </div>
            </div>
            <div className="text-center md:text-left relative z-10">
                <h3 className="font-heading text-xl font-bold text-white mb-2">Garantía #1: Claridad de 7 Días</h3>
                <p className="text-stone-400 text-sm leading-relaxed">
                    Si no entiendes la materia mejor que con tu profesor en la primera semana, te devolvemos el 100% de tu dinero. <span className="text-white font-semibold">Sin preguntas.</span>
                </p>
            </div>
        </div>
    );
};

// --- GUARANTEE SEAL 2 (BONUS) ---
export const BonusGuarantee: React.FC = () => {
    return (
        <div className="flex flex-col md:flex-row items-center gap-6 bg-stone-900/30 border border-dashed border-neon-purple/50 p-8 rounded-2xl w-full relative overflow-hidden group hover:bg-stone-900/50 transition-colors">
             {/* Background Glow */}
            <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-neon-purple/5 blur-[80px] rounded-full pointer-events-none group-hover:bg-neon-purple/10 transition-all"></div>
            
            <div className="flex-shrink-0">
                 <div className="w-20 h-20 rounded-full border-2 border-neon-purple flex items-center justify-center bg-black shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                    <Gift size={40} className="text-neon-purple" />
                 </div>
            </div>
            <div className="text-center md:text-left relative z-10">
                <h3 className="font-heading text-xl font-bold text-white mb-2">Garantía #2: "Quédate con los Bonus"</h3>
                <p className="text-stone-400 text-sm leading-relaxed">
                    Incluso si pides el reembolso, <span className="text-neon-purple font-bold">te regalamos las Hojas de Trucos (Valor $10 USD)</span> para siempre. Es nuestra forma de agradecerte por intentarlo.
                </p>
            </div>
        </div>
    );
};

// --- AUTHOR CARD ---
export const AuthorBio: React.FC = () => {
    return (
        <div className="flex flex-col md:flex-row items-center gap-8 p-8 bg-gradient-to-br from-stone-900 to-black rounded-2xl border border-stone-800 shadow-xl max-w-3xl mx-auto">
            <div className="w-32 h-32 md:w-40 md:h-40 flex-shrink-0 rounded-full overflow-hidden border-2 border-stone-700 relative flex items-center justify-center bg-stone-800">
                 <span className="text-6xl md:text-7xl" role="img" aria-label="Teacher">👨‍🏫</span>
            </div>
            <div className="text-center md:text-left">
                <h4 className="text-neon-blue text-xs font-bold tracking-widest uppercase mb-2">EL CREADOR</h4>
                <h3 className="font-heading text-2xl font-bold text-white mb-4">John Soto</h3>
                <p className="text-stone-400 italic mb-4">
                    "Me cansé de ver a estudiantes brillantes reprobar por usar métodos del siglo XIX."
                </p>
                <p className="text-sm text-stone-500 leading-relaxed">
                    Estratega digital obsesionado con la optimización del aprendizaje. Creé el Método Aprobado no para ser otro libro de texto, sino como un manual de operaciones para hackear la curva de aprendizaje de anatomía.
                </p>
            </div>
        </div>
    );
};
